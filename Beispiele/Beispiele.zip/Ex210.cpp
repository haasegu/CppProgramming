//	Ex210.cpp

//	Sec. 2.1 of lecture
//	Conventions for naming variables

#include <iostream>
using namespace std;

int main()
{
 int i, j, ijl, i3, _3a, Drei_mal_A; 		//   valid names
 
// int 3i;					// invalid name

// int _3*a;					// invalid name

// int auto;					// invalid name

 int leitner1, Leitner1;			// case sensitive
 
//			more than 8 significant initial characters
 int a1234567890123456789012345678901234567890;	
 int a12345678901234567890123456789012345678901;

 cout << "Hello World\n";
 
 return 0;
}
 
 
 
 
 
 
 
 
 
