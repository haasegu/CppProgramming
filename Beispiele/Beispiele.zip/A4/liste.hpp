// Demonstration, da� mit virtuellen Funktionen ein �bersetzter
// Programmteil nachtr�glich ver�ndert werden kann.
#include <vector>
#include "employ2.hpp"

void PrintListe(const std::vector<Employee*>& liste );

 
